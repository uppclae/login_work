const mongoose= require('mongoose');
const  bcrypt= require('bcrypt');
const express= require('express');
const cors= require('cors');
const User=require('./model');
const { response } = require('express');

//mongodb://localhost:27017
//mongodb+srv://ashvrm67:openmongodb2022@cluster0.wdwitjx.mongodb.net/MongoSampleDB?retryWrites=true&w=majority
const app= express();
const PORT=8080;
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb+srv://ashvrm67:openmongodb2022@cluster0.wdwitjx.mongodb.net/SampleDB2')
.then(()=>console.log("connection OK") )
.catch((e)=>console.log("error in connection"));


app.listen(PORT,()=>{

console.log(`server listing at ${PORT}`);

})


app.get("/", async(req, res)=>{

res.status(200).json({message:"you have reached server"});

})

app.post("/login", async(req, res)=>{
console.log("inside server login");

const emailid= req.body.user;
const password= req.body.pass;
console.log({emailid});
console.log({password});

var user= await User.findOne({email:emailid});
if(user)
{
    
console.log("user found");
console.log(user);

res.status(200).json({message:""+user});
}
else
{

console.log("user Not found ") ;   
res.status(404).json({message:"User not found"});

}



})





