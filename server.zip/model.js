
const mongoose= require('mongoose');
const userName= mongoose.Schema({
firstName:String,
lastName:String,
age:{type:Number},
email:{type:String, require:true},
password:{type:String, required:true, minLength:8}

});

const User= new mongoose.model("MongoUser", userName);

module.exports=User;

