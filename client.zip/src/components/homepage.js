import React from 'react';
import {useState} from 'react';
import ReactDOM from 'react-dom/client';
import '../index.css';
import axios from 'axios';
//import Homepage from './homepage';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.js';



const Homepage=(prop)=>
{
console.log("user id at home page"+prop.data);

return(<>
<h6 style={{textAlign:'center'}}>Welcome {prop.data}</h6>;
</>);

}



export default Homepage;
