import React from 'react';
import {useState} from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import axios from 'axios';
//import Homepage from './homepage';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/js/bootstrap.js';
import Homepage from './components/homepage.js';


const root = ReactDOM.createRoot(document.getElementById('root'));
const Server= "";


const App=()=>
{
  const [error, setError]= useState(true);
    const [success,setSuccess]= useState(0);

const [userid, setUserid]= useState("");
const [password, setPassword]= useState("");

const handleUserid=(event)=>
{
    setUserid(event.target.value);
   // console.log(event.target.value);
} 
const handlePassword=(event)=>
{
    setPassword(event.target.value);
   // console.log(event.target.value);
} 
const handleSubmit= async()=>
{
console.log("submit clicked");
console.log({userid});
console.log({password});
await axios.post('http://localhost:8080/login',
{
  user:userid,
  pass:password
}).then((response)=>{
  
if(response.status==200)    

  console.log(response);
  console.log("move to homepage");
  <Homepage data={userid} />
  


}).catch((error)=>{console.log(error)});

}

return (
<>
<div  className='container_login'>
<div className='header_login' >
</div>
<div className="body_login">
<div  className="login_div">
<h5 className='align_center mt-3'>Login Page</h5>
<div className='main'>
<div className="input-group width_20 mt-5 d-flex flex-column"  style={{alignItems:'center' }} >
<span style={{fontSize:13,}}><h6>User Id</h6></span>
<input type="text" class="form-control bord mt-1"  placeholder="Enter Your ID" onChange={handleUserid}  style={{width:'80%', height:45}} />
</div>
<div className="input-group mb- width_20 mt-4 d-flex flex-column" style={{alignItems:'center'}} >
  <span style={{fontSize:13}} ><h6>Password</h6> </span>

    <input type="Password" className="form-control border mt-2 items" placeholder="Enter Password" onChange={handlePassword} style={{width:'80%' ,height:45,alignItems:'center'}}/>

</div>


<button type="button" className="btn btn-primary mt-5 width_15 " style={{alignItems:'center',width:'80%' ,height:45, backgroundColor:'#342D7E'}} onClick={handleSubmit}>Submit</button>
<div className='d-flex'></div>
<a href="#" className='mt-3'>Forget Password?</a>
<div className='mt-4'> New User? <a href="#" >Sign Up</a></div>
</div>


</div>
</div>

<div className="footer_login">
</div>

</div>

</>
);

}

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

